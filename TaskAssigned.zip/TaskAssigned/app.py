from flask import Flask, render_template, request, flash, redirect, url_for
import sqlite3

app = Flask(__name__)
app.secret_key = "abc" 


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/add")
def add(): 
    return render_template("add.html")


@app.route("/savedetails", methods=["POST", "GET"])
def saveDetails():
    msg = "msg"
    if request.method == "POST": 
        try:
            aid = request.form["aid"]
            qid = request.form["qid"]
            amount = request.form["amount"]
            task = request.form["task"]
            state = request.form["state"]
            reason = request.form["reason"]

            with sqlite3.connect("taskrecord.db") as con:
                cur = con.cursor()
                cur.execute(
                    "INSERT into record(aid, qid, amount, task, state, reason) values (?,?,?,?,?,?)",
                    (aid, qid, amount, task, state, reason))

                con.commit()
                msg = "Records Are Added"
        except:
            con.rollback()
            msg = "Records Insertion Failed"
        finally:
            flash("Record Inserted")

            return redirect(url_for('views', msg=msg))
            con.close()


@app.route("/display")
def display():
    con = sqlite3.connect("taskrecord.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("select * from record")
    rows = cur.fetchall()
    return render_template("display.html", rows=rows)


@app.route("/delete")
def delete():
    return render_template("delete.html")


@app.route("/deleterecord", methods=["POST"])
def deleterecord():
    aid = request.form["aid"]
    qid = request.form["qid"]
    with sqlite3.connect("taskrecord.db") as con:
        try:
            cur = con.cursor()

            cur.execute("delete from record where aid = ?", (aid,))
            cur.execute("delete from record where qid = ?", (qid,))
            msg = "record successfully deleted"
        except:
            msg = "can't be deleted"
        finally:
            return render_template("delete_record.html", msg=msg)


