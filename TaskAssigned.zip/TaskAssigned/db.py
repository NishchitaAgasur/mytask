import sqlite3
con=sqlite3.connect("taskrecord.db")
print("Database created")
con.execute("create table record1(Date_t TEXT DEFAULT CURRENT_TIMESTAMP,aid INTEGER PRIMARY KEY,qid INTEGER NOT NULL,amount INTEGER NOT NULL,task FLOAT,state INTEGER,reason TEXT)")
print("Table created successfully")
con.close()
